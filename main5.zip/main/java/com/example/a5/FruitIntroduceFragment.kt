package com.example.a5

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.constraintlayout.helper.widget.Carousel.Adapter
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class FruitIntroduceFragment:Fragment() {
    val fruitList=ArrayList<Fruit>()
    var isTwoPane=false
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        Log.d("FruitIntroduceFragment", "onCreateView called")

        return inflater.inflate(R.layout.fragment_fruit_introduce,container,false)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        Log.d("FruitIntroduceFragment", "onActivityCreated called")

        isTwoPane=activity?.findViewById<View>(R.id.fruitBuyFrag)!=null
        val fruitIntroduceRecycler:RecyclerView?=activity?.findViewById(R.id.fruitIntroduceRecycler)
        initFruit()
        val frag2=activity?.supportFragmentManager?.findFragmentById(R.id.fruitBuyFrag) as? FruitBuyFragment
        fruitIntroduceRecycler?.adapter=FruitAdapter(fruitList,this,frag2)
        fruitIntroduceRecycler?.layoutManager=LinearLayoutManager(activity)
        Log.d("FruitIntroduceFragment", "onActivityCreated called1")

    }

    private fun initFruit(){
        repeat(4){
            fruitList.add(Fruit(R.drawable.apple_pic,"Apple",2))
            fruitList.add(Fruit(R.drawable.cherry_pic,"cherry",3))
            fruitList.add(Fruit(R.drawable.banana_pic,"banana",4))
            fruitList.add(Fruit(R.drawable.mango_pic,"mango",5))
        }
    }
}