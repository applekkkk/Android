package com.example.a5

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View

class FruitBuyActivity : AppCompatActivity() {
    companion object {
        fun actionStart(context: Context,name:String,img:Int,price:Int){
            val intent=Intent(context,FruitBuyActivity::class.java)
            intent.putExtra("name",name)
            intent.putExtra("img",img)
            intent.putExtra("price",price)
            context.startActivity(intent)
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_fruit_buy)
        val name=intent.getStringExtra("name")
        val img=intent.getIntExtra("img",0)
        val price=intent.getIntExtra("price",0)
        val frag=supportFragmentManager.findFragmentById(R.id.fragg)
        if(frag is FruitBuyFragment){
            if(name!=null) {
                frag.refresh(name, img, price)
                frag.price = price
                frag.amount=1
            }
        }
    }
}