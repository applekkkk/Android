package com.example.a5

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import org.w3c.dom.Text

class FruitBuyFragment:Fragment() {
    var price=0
    var amount=1
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_fruit_buy,container,false)
    }
    fun refresh(name:String,img:Int,price:Int){
        val nameText: TextView? = activity?.findViewById(R.id.nameText)
        val imgView:ImageView?=activity?.findViewById(R.id.imageView)
        val priceText:TextView?=activity?.findViewById(R.id.priceText)
        val amountText:TextView?=activity?.findViewById(R.id.amountText)
        val totalText:TextView?=activity?.findViewById(R.id.totalText)
        nameText?.setText(name)
        imgView?.setImageResource(img)
        priceText?.setText("Unit price:  $$price.00/kg")
        amountText?.setText("1")
        val amount=amountText?.text.toString().toInt()
        totalText?.setText("Total price:  $${price*amount}.00")
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        val subBtn: Button?=activity?.findViewById(R.id.subBtn)
        val addBtn: Button?=activity?.findViewById(R.id.addBtn)
        val totalPriceText:TextView?=activity?.findViewById(R.id.totalText)
        val amountText:TextView?=activity?.findViewById(R.id.amountText)
        val orderBtn:Button?=activity?.findViewById(R.id.orderBtn)
        subBtn?.setOnClickListener {
            if(amount==0){
                Toast.makeText(activity,"Already 0",Toast.LENGTH_SHORT).show()
            }else{
                amount--
                totalPriceText?.setText("Total price:  $${price*amount}.00")
                amountText?.setText(amount.toString())
            }
        }
        addBtn?.setOnClickListener {
            amount++
            totalPriceText?.setText("Total price:  $${price*amount}.00")
            amountText?.setText(amount.toString())
        }
        orderBtn?.setOnClickListener {
            Toast.makeText(activity,"Order Success",Toast.LENGTH_SHORT).show()
        }
    }
}