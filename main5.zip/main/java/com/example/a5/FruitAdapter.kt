package com.example.a5

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class Fruit(val imgId:Int,val name:String,val price:Int)
class FruitAdapter(val fruitList:List<Fruit>,val frag1:FruitIntroduceFragment,val frag2:FruitBuyFragment?):RecyclerView.Adapter<FruitAdapter.ViewHolder>() {
    inner class ViewHolder(view:View):RecyclerView.ViewHolder(view){
        val imgView2:ImageView=view.findViewById(R.id.imageView2)
        val nameText1:TextView=view.findViewById(R.id.nameText1)
        val priceText1:TextView=view.findViewById(R.id.priceText1)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view=LayoutInflater.from(parent.context).inflate(R.layout.recycler_fruit,parent,false)
        val viewHolder=ViewHolder(view)
        viewHolder.itemView.setOnClickListener {
            val fruit=fruitList[viewHolder.position]
            if(frag1.isTwoPane){
                frag2?.refresh(fruit.name,fruit.imgId,fruit.price)
                frag2?.amount=1
                frag2?.price=fruit.price
            }else{
                FruitBuyActivity.actionStart(parent.context,fruit.name,fruit.imgId,fruit.price)
            }
        }
        return viewHolder
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val fruit=fruitList[position]
        holder.nameText1.setText(fruit.name)
        holder.imgView2.setImageResource(fruit.imgId)
        holder.priceText1.setText("$${fruit.price}.00/kg")
    }

    override fun getItemCount(): Int {
        return fruitList.size
    }
}