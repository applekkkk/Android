package com.example.a8

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ListView

class QueryActivity : AppCompatActivity() {
    val studentList=ArrayList<Student>()
    lateinit var adapter: StudentAdapter
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_query)
        initStudent()
        val studentListView:ListView=findViewById(R.id.dataList)
        adapter= StudentAdapter(this,R.layout.item_student,studentList)
        studentListView.adapter=adapter
        studentListView.setOnItemClickListener { parent, view, position, id ->
            val student=studentList[position]
            val intent= Intent(this,ReviseActivity::class.java)
            intent.putExtra("id",student.id)
            intent.putExtra("name",student.name)
            intent.putExtra("institute",student.institute)
            intent.putExtra("age",student.age)
            intent.putExtra("phone",student.phone)
            startActivity(intent)
        }
    }
    private fun initStudent(){
        studentList.clear()
        val uri=Uri.parse("content://com.example.a7.provider/Student")
        contentResolver.query(uri,null,null,null,null)?.apply {
            while (moveToNext()) {
                val id = getString(getColumnIndex("id"))
                val name = getString(getColumnIndex("name"))
                val institute = getString(getColumnIndex("institute"))
                val age = getInt(getColumnIndex("age"))
                val phone = getString(getColumnIndex("phone"))
                studentList.add(Student(id, name, age, institute, phone))
            }
            close()
        }
    }

    override fun onResume() {
        super.onResume()
        initStudent()
        adapter.notifyDataSetChanged()
    }
}