package com.example.a8

import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.core.content.contentValuesOf

class ReviseActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_revise)
        val idText: TextView =findViewById(R.id.reviseidText)
        val nameText: EditText =findViewById(R.id.revisenameText)
        val instituteText: EditText =findViewById(R.id.reviseinstituteText)
        val ageText: EditText =findViewById(R.id.reviseageText)
        val phoneText: EditText =findViewById(R.id.revisephoneText)
        val id=intent.getStringExtra("id")
        val name=intent.getStringExtra("name")
        val institute=intent.getStringExtra("institute")
        val age=intent.getIntExtra("age",0)
        val phone=intent.getStringExtra("phone")
        idText.setText(id)
        nameText.setText(name)
        instituteText.setText(institute)
        ageText.setText(age.toString())
        phoneText.setText(phone)
        val reviseBtn: Button =findViewById(R.id.reviseBtn)
        val deleteBtn: Button =findViewById(R.id.revisedeleteBtn)
        reviseBtn.setOnClickListener {
            val uri=Uri.parse("content://com.example.a7.provider/Student")
            val values= contentValuesOf("id" to idText.text.toString(),
                "name" to nameText.text.toString(),
                "institute" to instituteText.text.toString(),
                "age" to ageText.text.toString().toInt(),
                "phone" to phoneText.text.toString())
            contentResolver.update(uri,values,"id=?", arrayOf(id))
            finish()
        }
        deleteBtn.setOnClickListener {
            val uri=Uri.parse("content://com.example.a7.provider/Student")
            contentResolver.delete(uri,"id=?", arrayOf(id))
            finish()
        }
    }
}