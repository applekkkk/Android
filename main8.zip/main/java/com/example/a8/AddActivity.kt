package com.example.a8

import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.core.content.contentValuesOf

class AddActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add)
        val idText: EditText =findViewById(R.id.idText)
        val nameText: EditText =findViewById(R.id.nameText)
        val instituteText: EditText =findViewById(R.id.instituteText)
        val ageText: EditText =findViewById(R.id.ageText)
        val phoneText: EditText =findViewById(R.id.phoneText)
        val addBtn:Button=findViewById(R.id.insertBtn)
        addBtn.setOnClickListener {
            val uri= Uri.parse("content://com.example.a7.provider/Student")
            val values= contentValuesOf("id" to idText.text.toString(),
                "name" to nameText.text.toString(),
                "institute" to instituteText.text.toString(),
                "age" to ageText.text.toString().toInt(),
                "phone" to phoneText.text.toString())
            contentResolver.insert(uri,values)
            finish()
        }
    }
}