package com.example.a8

import android.app.Activity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.TextView

class Student(val id:String,val name:String,val age:Int,val institute:String,val phone:String)
class StudentAdapter(activity: Activity,val resourceId:Int,data:List<Student>):ArrayAdapter<Student>(activity,resourceId,data) {
    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val view=LayoutInflater.from(context).inflate(resourceId,parent,false)
        val nameText:TextView=view.findViewById(R.id.ItemNameText)
        val idText:TextView=view.findViewById(R.id.ItemIdText)
        val instituteText:TextView=view.findViewById(R.id.ItemInstituteText)
        val student=getItem(position)
        if(student!=null){
            nameText.setText(student.name)
            idText.setText(student.id)
            instituteText.setText(student.institute)
        }
        return view
    }
}