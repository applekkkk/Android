package com.example.a8

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val addDataBtn: Button =findViewById(R.id.addDataBtn)
        val queryBtn: Button =findViewById(R.id.queryDataBtn)
        addDataBtn.setOnClickListener {
            val intent= Intent(this,AddActivity::class.java)
            startActivity(intent)
        }
        queryBtn.setOnClickListener {
            val intent= Intent(this,QueryActivity::class.java)
            startActivity(intent)
        }
    }
}