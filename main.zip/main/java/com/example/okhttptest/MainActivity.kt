package com.example.okhttptest

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.util.Xml
import android.widget.Button
import android.widget.TextView
import okhttp3.Call
import okhttp3.Callback
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import org.json.JSONArray
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.io.IOException
import java.io.StringReader
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val button:Button=findViewById(R.id.button)
        button.setOnClickListener {
            sendRequestWithOkHttp()
        }
    }
    private fun sendRequestWithOkHttp(){
        HttpUtil.sendOkHttpRequest("http://10.61.52.138:5000/hello",object :Callback{
            override fun onResponse(call: Call, response: Response) {
                val responseData=response.body?.string()
                Log.d("Main","response is $responseData")
                if (responseData != null) {
                    parseXMLWithPull(responseData)
                }
            }

            override fun onFailure(call: Call, e: IOException) {
                e.printStackTrace()
            }
        })
    }

    private fun parseJSONWithJSONObject(jsonData:String){
        Log.d("Main",jsonData)
        val jsonArray=JSONArray(jsonData)
        val idText:TextView=findViewById(R.id.idText)
        val nameText:TextView=findViewById(R.id.nameText)
        val versionText:TextView=findViewById(R.id.versionText)
        for(i in 0..jsonArray.length()){
            val jsonObject=jsonArray.getJSONObject(i)
            val id=jsonObject.getString("id")
            val name=jsonObject.getString("name")
            val version=jsonObject.getString("version")
            Log.d("Main","id is $id")
            Log.d("Main","name is $name")
            Log.d("Main","version is $version")
            runOnUiThread {
                idText.text=id
                nameText.setText(name)
                versionText.text=version
            }
        }
    }

    private fun parseXMLWithPull(xmlData:String){
        try{
            Log.d("Main",xmlData)
            val factory=XmlPullParserFactory.newInstance()
            factory.isNamespaceAware = true;
            val xmlPullParser=factory.newPullParser()
            xmlPullParser.setInput(StringReader(xmlData))
            var eventType=xmlPullParser.eventType
            var id=""
            var name=""
            var version=""
            val idText:TextView=findViewById(R.id.idText)
            val nameText:TextView=findViewById(R.id.nameText)
            val versionText:TextView=findViewById(R.id.versionText)
            while (eventType!= XmlPullParser.END_DOCUMENT){
                Log.d("Main","eventType is $eventType")
                val nodeName=xmlPullParser.name
                when(eventType){
                    XmlPullParser.START_TAG->{
                        Log.d("Main","start:$nodeName")
                        when(nodeName){
                            "id"->id=xmlPullParser.nextText()
                            "name"->name=xmlPullParser.nextText()
                            "version"->version=xmlPullParser.nextText()
                        }
                    }
                    XmlPullParser.END_TAG->{
                        runOnUiThread {
                            Log.d("Main","end:$nodeName")
                            when(nodeName){
                                "app"->{
                                    idText.setText(id)
                                    nameText.setText(name)
                                    versionText.setText(version)
                                }
                            }
                        }
                    }
                }
                eventType=xmlPullParser.next()
            }
        }catch (e:Exception){
            e.printStackTrace()
        }
    }
}