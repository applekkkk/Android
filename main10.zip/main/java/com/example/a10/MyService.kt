package com.example.a10

import android.app.Activity
import android.app.IntentService
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.os.Binder
import android.os.IBinder
import android.util.Log
import kotlin.concurrent.thread
import kotlin.math.pow

class MyService(): IntentService("1") {
    private val mBinder=AlterFactorBinder()

    override fun onBind(intent: Intent): IBinder {
        return mBinder
    }

    override fun onHandleIntent(intent: Intent?) {

    }

    class AlterFactorBinder():Binder(){
        lateinit var newBit:Bitmap
        fun alter(activity: Activity, bitmap:Bitmap,factor: Double){
            thread {
                newBit=bitmap.applyGammaCorrection(factor)
                val intent=Intent("change")
                intent.setPackage(activity.packageName)
                activity.sendBroadcast(intent)
            }
        }
        fun Bitmap.applyGammaCorrection(gamma: Double): Bitmap {
            val width = this.width
            val height = this.height
            val result = Bitmap.createBitmap(width, height, this.config)
            for (x in 0 until width) {
                for (y in 0 until height) {
                    val color = this.getPixel(x, y)
                    val red = color and 0xFF
                    val green = (color shr 8) and 0xFF
                    val blue = (color shr 16) and 0xFF
                    val alpha = color ushr 24

                    val newRed = (red.toDouble() / 255.0).pow(gamma) * 255.0
                    val newGreen = (green.toDouble() / 255.0).pow(gamma) * 255.0
                    val newBlue = (blue.toDouble() / 255.0).pow(gamma) * 255.0

                    val newColor = (alpha shl 24) or ((newRed.toInt() and 0xFF) shl 16) or
                            ((newGreen.toInt() and 0xFF) shl 8) or (newBlue.toInt() and 0xFF)

                    result.setPixel(x, y, newColor)
                }
            }
            return result
        }
    }


}