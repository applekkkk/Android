package com.example.a10

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.ServiceConnection
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.AsyncTask
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.Message
import android.provider.ContactsContract.CommonDataKinds.Im
import android.util.Log
import android.widget.Button
import android.widget.ImageView
import android.widget.SeekBar
import android.widget.Toast
import kotlin.concurrent.thread
import kotlin.math.pow

class MainActivity : AppCompatActivity() {
    lateinit var bitmap: Bitmap
    lateinit var newbit:Bitmap
    var factor:Double=1.0
    val update_imageView=1
    lateinit var myReceiver: MyReceiver
    lateinit var myBinder:MyService.AlterFactorBinder
    private val connection=object :ServiceConnection{
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            Log.d("Main",factor.toString())
            myBinder=service as MyService.AlterFactorBinder
            myBinder.alter(this@MainActivity,bitmap,factor)

        }


        override fun onServiceDisconnected(name: ComponentName?) {
        }
    }
    inner class MyReceiver:BroadcastReceiver(){
        override fun onReceive(context: Context?, intent: Intent?) {
            newbit=myBinder.newBit
            val imageView:ImageView=findViewById(R.id.imageView)
            imageView.setImageBitmap(newbit)
            unbindService(connection)
        }
    }
    val handler=object :Handler(Looper.getMainLooper()){
        override fun handleMessage(msg: Message) {
            when(msg.what){
                update_imageView->{
                    val imageView:ImageView=findViewById(R.id.imageView)
                    imageView.setImageBitmap(newbit)
                }
            }
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val intentFilter=IntentFilter()
        intentFilter.addAction("change")
        myReceiver=MyReceiver()
        registerReceiver(myReceiver,intentFilter)
        val browseBtn:Button=findViewById(R.id.browseBtn)
        browseBtn.setOnClickListener {
            val intent=Intent(Intent.ACTION_OPEN_DOCUMENT)
            intent.addCategory(Intent.CATEGORY_OPENABLE)
            intent.type="image/*"
            startActivityForResult(intent,1)
        }
        val changeFactorBtn:Button=findViewById(R.id.changeFactorBtn)
        val seekBar:SeekBar=findViewById(R.id.seekBar)

        changeFactorBtn.setOnClickListener {
            factor=seekBar.progress.toDouble()/50
            val intent=Intent(this,MyService::class.java)
            Log.d("Main","click")
            bindService(intent,connection,Context.BIND_AUTO_CREATE)
        }
    }



    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when(requestCode){
            1->{
                if(resultCode==Activity.RESULT_OK && data!=null){
                    data.data?.let { uri ->
                        val bitmap1=getBitmapFromUri(uri)
                        val imageView:ImageView=findViewById(R.id.imageView)
                        imageView.setImageBitmap(bitmap1)
                        if (bitmap1 != null) {
                            bitmap=bitmap1
                        }

                    }
                }
            }
        }
    }

    private fun getBitmapFromUri(uri: Uri)=contentResolver
        .openFileDescriptor(uri,"r")?.use {
            BitmapFactory.decodeFileDescriptor(it.fileDescriptor)
        }

    fun Bitmap.applyGammaCorrection(gamma: Double): Bitmap {
        val width = this.width
        val height = this.height
        val result = Bitmap.createBitmap(width, height, this.config)
        for (x in 0 until width) {
            for (y in 0 until height) {
                val color = this.getPixel(x, y)
                val red = color and 0xFF
                val green = (color shr 8) and 0xFF
                val blue = (color shr 16) and 0xFF
                val alpha = color ushr 24

                val newRed = (red.toDouble() / 255.0).pow(gamma) * 255.0
                val newGreen = (green.toDouble() / 255.0).pow(gamma) * 255.0
                val newBlue = (blue.toDouble() / 255.0).pow(gamma) * 255.0

                val newColor = (alpha shl 24) or ((newRed.toInt() and 0xFF) shl 16) or
                        ((newGreen.toInt() and 0xFF) shl 8) or (newBlue.toInt() and 0xFF)

                result.setPixel(x, y, newColor)
            }
        }
        return result
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterReceiver(myReceiver)
    }



}