package com.example.a10

import android.app.IntentService
import android.content.Intent

class AlterFactorService:IntentService("1") {
    override fun onHandleIntent(intent: Intent?) {
        TODO("Not yet implemented")
    }
}