package com.example.a4

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class DialogActivity : AppCompatActivity() {
    private val dialogList=ArrayList<Dialog>()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dialog)
        initDialog()
        val layoutManager=LinearLayoutManager(this)
        val dialogRecycler:RecyclerView=findViewById(R.id.recyclerDialog)
        val adapter=DialogAdapter(dialogList,this)
        dialogRecycler.adapter=adapter
        dialogRecycler.layoutManager=layoutManager
    }
    private fun initDialog(){
        dialogList.clear()
        repeat(3){
            dialogList.add(Dialog(R.drawable.work,"work","I am working"))
            dialogList.add(Dialog(R.drawable.mute,"mute","I am muting"))
            dialogList.add(Dialog(R.drawable.apple_pic,"apple","I am an apple"))
            dialogList.add(Dialog(R.drawable.banana_pic,"bananas","I am bananas"))
        }
    }
}