package com.example.a4

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import de.hdodenhof.circleimageview.CircleImageView

class Chat(val avatarId:Int,val msg:String,val type:Int){
    companion object{
        const val LEFT=0
        const val RIGHT=1
    }
}
class ChatAdapter(val chatList: List<Chat>):RecyclerView.Adapter<RecyclerView.ViewHolder>() {
    inner class LeftViewHolder(view:View):RecyclerView.ViewHolder(view){
        val msgTextL:TextView=view.findViewById(R.id.msgTextL)
        val avatarIdL:CircleImageView=view.findViewById(R.id.avatarImageViewL)
    }
    inner class RightViewHolder(view: View):RecyclerView.ViewHolder(view){
        val msgTextR:TextView=view.findViewById(R.id.msgTextR)
        val avatarIdR:CircleImageView=view.findViewById(R.id.avatarImageViewR)
    }

    override fun getItemViewType(position: Int): Int {
        val msg=chatList[position]
        return msg.type
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        if(viewType==Chat.LEFT){
            val view=LayoutInflater.from(parent.context).inflate(R.layout.item_left_msg,parent,false)
            return LeftViewHolder(view)
        }else {
            val view=LayoutInflater.from(parent.context).inflate(R.layout.item_right_msg,parent,false)
            return RightViewHolder(view)
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val chat=chatList[position]
        when(holder){
            is LeftViewHolder-> {
                holder.avatarIdL.setImageResource(chat.avatarId)
                holder.msgTextL.text=chat.msg
            }
            is RightViewHolder->{
                holder.avatarIdR.setImageResource(chat.avatarId)
                holder.msgTextR.text=chat.msg
            }
        }
    }

    override fun getItemCount(): Int {
        return chatList.size
    }
}