package com.example.a4

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class ChatActivity : AppCompatActivity() {
    private val chatList=ArrayList<Chat>()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat)
        val chatRecycler:RecyclerView=findViewById(R.id.chatRecycler)
        chatRecycler.layoutManager=LinearLayoutManager(this)
        val avatarR=intent.getIntExtra("avatarI",0)
        initMsg()
        val adapter=ChatAdapter(chatList)
        chatRecycler.adapter=adapter
        val sendBtn:Button=findViewById(R.id.sendBtn)
        sendBtn.setOnClickListener {
            val inputText:EditText=findViewById(R.id.inputText)
            val content=inputText.text.toString()
            if(content.isNotEmpty()){
                chatList.add(Chat(avatarR,content,Chat.RIGHT))
                adapter.notifyDataSetChanged()
                chatRecycler.scrollToPosition(chatList.size-1)
                inputText.setText("")
            }
        }
    }
    private fun initMsg(){
        val avatarL=intent.getIntExtra("avatarY",0)
        val avatarR=intent.getIntExtra("avatarI",0)
        val sentence=intent.getStringExtra("sentence")
        chatList.add(Chat(avatarR,"Hey",Chat.RIGHT))
        if (sentence!=null)
            chatList.add(Chat(avatarL,sentence,Chat.LEFT))
    }
}