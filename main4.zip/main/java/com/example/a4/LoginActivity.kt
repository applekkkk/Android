package com.example.a4

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AlertDialog

class LoginActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        val loginBtn:Button=findViewById(R.id.loginBtn)
        val exitBtn:Button=findViewById(R.id.exitBtn)
        exitBtn.setOnClickListener {
            finish()
        }
        loginBtn.setOnClickListener {
            val passwordText:TextView=findViewById(R.id.passwordText)
            if(passwordText.text.toString()=="qq"){
                val intent=Intent(this,DialogActivity::class.java)
                intent.putExtra("avatar",R.drawable.mh)
                startActivity(intent)
            }else{
                AlertDialog.Builder(this).apply {
                    setTitle("Error")
                    setMessage("密码错误")
                    setCancelable(true)
                    setPositiveButton("Ok"){dialog,which->}
                    show()
                }
            }
        }
    }
}