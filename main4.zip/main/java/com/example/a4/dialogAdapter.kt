package com.example.a4

import android.app.Activity
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import de.hdodenhof.circleimageview.CircleImageView

class Dialog(val avatarId:Int, val name:String, val sentence:String)
class DialogAdapter(val dialogList:List<Dialog>,val activity: Activity):RecyclerView.Adapter<DialogAdapter.ViewHolder> (){
    inner class ViewHolder(view: View):RecyclerView.ViewHolder(view){
        val avatorImageView:CircleImageView=view.findViewById(R.id.avatorImageView2)
        val nameText:TextView=view.findViewById(R.id.nameText)
        val senteneceText:TextView=view.findViewById(R.id.sentenceText)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int):ViewHolder {
        val view=LayoutInflater.from(parent.context).inflate(R.layout.item_dialog_recycler,parent,false)
        val viewHolder= ViewHolder(view)
        viewHolder.itemView.setOnClickListener {
            val dialog=dialogList[viewHolder.adapterPosition]
            val avatarI=activity.intent.getIntExtra("avatar",0)
            val avatarY=dialog.avatarId
            val sentence=dialog.sentence
            val intent=Intent(parent.context,ChatActivity::class.java)
            intent.putExtra("avatarI",avatarI)
            intent.putExtra("avatarY",avatarY)
            intent.putExtra("sentence",sentence)
            parent.context.startActivity(intent)
        }
        return viewHolder
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val dialog=dialogList[position]
        holder.avatorImageView.setImageResource(dialog.avatarId)
        holder.nameText.text=dialog.name
        holder.senteneceText.text=dialog.sentence
    }

    override fun getItemCount(): Int {
        return dialogList.size
    }
}