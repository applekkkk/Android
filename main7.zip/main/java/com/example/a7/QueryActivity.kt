package com.example.a7

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ListView

class QueryActivity : AppCompatActivity() {
    val studentList=ArrayList<Student>()
    lateinit var adapter: StudentAdapter
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_query)
        initStudent()
        val studetListView:ListView=findViewById(R.id.dataList)
        adapter=StudentAdapter(this,R.layout.item_student,studentList)
        studetListView.adapter=adapter
        studetListView.setOnItemClickListener { parent, view, position, id ->
            val student=studentList[position]
            val intent=Intent(this,ReviseActivity::class.java)
            intent.putExtra("id",student.id)
            intent.putExtra("name",student.name)
            intent.putExtra("institute",student.institute)
            intent.putExtra("age",student.age)
            intent.putExtra("phone",student.phone)
            startActivity(intent)
        }
    }
    private fun initStudent(){
        studentList.clear()
        val db=MyDatabaseHelper(this,"School.db",1).writableDatabase
        val cursor=db.rawQuery("select * from Student",null)
        if(cursor.moveToFirst()){
            do {
                val name=cursor.getString(cursor.getColumnIndex("name"))
                val id=cursor.getString(cursor.getColumnIndex("id"))
                val institute=cursor.getString(cursor.getColumnIndex("institute"))
                val age=cursor.getInt(cursor.getColumnIndex("age"))
                val phone=cursor.getString(cursor.getColumnIndex("phone"))
                studentList.add(Student(id,name,institute,age,phone))
            }while (cursor.moveToNext())
        }
        cursor.close()
    }

    override fun onResume() {
        super.onResume()
        initStudent()
        adapter.notifyDataSetChanged()
    }
}