package com.example.a7

import android.content.ContentProvider
import android.content.ContentValues
import android.database.Cursor
import android.net.Uri

class MyContentProvider:ContentProvider() {
    private var authority="com.example.a7.provider"
    private var dbHelper:MyDatabaseHelper?=null

    override fun onCreate(): Boolean=context?.let {
        dbHelper=MyDatabaseHelper(it,"School.db",1)
        true
    }?:false

    override fun query(
        uri: Uri,
        projection: Array<out String>?,
        selection: String?,
        selectionArgs: Array<out String>?,
        sortOrder: String?
    ): Cursor?=dbHelper?.let {
        val db=it.readableDatabase
        val cursor=db.query("Student",projection,selection,selectionArgs,null,null,sortOrder)
        cursor
    }

    override fun insert(uri: Uri, values: ContentValues?): Uri?=dbHelper?.let {
        val db=it.writableDatabase
        val newStu=db.insert("Student",null,values)
        Uri.parse("content://$authority/Student/$newStu")
    }

    override fun update(
        uri: Uri,
        values: ContentValues?,
        selection: String?,
        selectionArgs: Array<out String>?
    ): Int=dbHelper?.let {
        val db=it.writableDatabase
        val updateRows=db.update("Student",values,selection,selectionArgs)
        updateRows
    }?:0

    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<out String>?): Int=dbHelper?.let {
        val db=it.writableDatabase
        val deletedRows=db.delete("Student",selection,selectionArgs)
        deletedRows
    }?:0

    override fun getType(uri: Uri): String? {
        return "vnd.android.cursor.dir/vnd.$authority.Student"
    }
}