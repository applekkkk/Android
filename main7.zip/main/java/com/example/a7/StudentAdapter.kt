package com.example.a7

import android.app.Activity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.TextView
import org.w3c.dom.Text

class Student(val id:String,val name:String,val institute:String,val age:Int,val phone:String)
class StudentAdapter(val activity: Activity,val resourceId:Int,val data:List<Student>):ArrayAdapter<Student>(activity,resourceId,data) {
    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val view=LayoutInflater.from(context).inflate(resourceId,parent,false)
        val nameText:TextView=view.findViewById(R.id.ItemNameText)
        val idText:TextView=view.findViewById(R.id.ItemIdText)
        val institute:TextView=view.findViewById(R.id.ItemInstituteText)
        val student=getItem(position)
        if(student!=null){
            idText.setText(student.id)
            nameText.setText(student.name)
            institute.setText(student.institute)
        }
        return view
    }
}