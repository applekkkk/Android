package com.example.a7

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText

class AddDataActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_data)
        val insertBtn:Button=findViewById(R.id.insertBtn)
        val db=MyDatabaseHelper(this,"School.db",1).writableDatabase
        insertBtn.setOnClickListener {
            val idText:EditText=findViewById(R.id.idText)
            val nameText:EditText=findViewById(R.id.nameText)
            val instituteText:EditText=findViewById(R.id.instituteText)
            val ageText:EditText=findViewById(R.id.ageText)
            val phoneText:EditText=findViewById(R.id.phoneText)
            db.execSQL("insert into Student (id,name,institute,age,phone) values(?,?,?,?,?)",
                arrayOf(idText.text.toString(),nameText.text.toString(),instituteText.text.toString(),ageText.text.toString().toInt(),phoneText.text.toString())
            )
            finish()
        }
    }
}