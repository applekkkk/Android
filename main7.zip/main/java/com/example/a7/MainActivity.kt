package com.example.a7

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val createBtn:Button=findViewById(R.id.createDbBtn)
        val addDataBtn:Button=findViewById(R.id.addDataBtn)
        val queryBtn:Button=findViewById(R.id.queryDataBtn)
        val dbHelper=MyDatabaseHelper(this,"School.db",1)
        createBtn.setOnClickListener {
            dbHelper.writableDatabase
        }
        addDataBtn.setOnClickListener {
            val intent=Intent(this,AddDataActivity::class.java)
            startActivity(intent)
        }
        queryBtn.setOnClickListener {
            val intent=Intent(this,QueryActivity::class.java)
            startActivity(intent)
        }
    }
}