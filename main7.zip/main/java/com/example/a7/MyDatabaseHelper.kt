package com.example.a7

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.widget.Toast

class MyDatabaseHelper(val context: Context,name:String,version:Int):SQLiteOpenHelper(context,name,null,version) {

    private val createSchool="create table Student(" +
            "id text primary key," +
            "name text," +
            "institute text," +
            "age integer," +
            "phone text)"

    override fun onCreate(db: SQLiteDatabase?) {
        db?.execSQL(createSchool)
        Toast.makeText(context,"Create Success",Toast.LENGTH_SHORT).show()
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {

    }
}