package com.example.a7

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import org.w3c.dom.Text

class ReviseActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_revise)
        val idText:TextView=findViewById(R.id.reviseidText)
        val nameText:EditText=findViewById(R.id.revisenameText)
        val instituteText:EditText=findViewById(R.id.reviseinstituteText)
        val ageText:EditText=findViewById(R.id.reviseageText)
        val phoneText:EditText=findViewById(R.id.revisephoneText)
        val id=intent.getStringExtra("id")
        val name=intent.getStringExtra("name")
        val institute=intent.getStringExtra("institute")
        val age=intent.getIntExtra("age",0)
        val phone=intent.getStringExtra("phone")
        idText.setText(id)
        nameText.setText(name)
        instituteText.setText(institute)
        ageText.setText(age.toString())
        phoneText.setText(phone)
        val reviseBtn:Button=findViewById(R.id.reviseBtn)
        val deleteBtn:Button=findViewById(R.id.revisedeleteBtn)
        val db=MyDatabaseHelper(this,"School.db",1).writableDatabase
        reviseBtn.setOnClickListener {
            db.execSQL("update Student set name=?,institute=?,age=?,phone=? where id=?",
                arrayOf(nameText.text.toString(),instituteText.text.toString(),ageText.text.toString().toInt(),phoneText.text.toString(),idText.text.toString()))
            finish()
        }
        deleteBtn.setOnClickListener {
            db.execSQL("delete from Student where id=?", arrayOf(id))
            finish()
        }
    }
}