package com.example.a9

import android.app.Activity
import android.content.ContentProvider
import android.content.ContentResolver
import android.content.ContentResolver.MimeTypeInfo
import android.content.Context
import android.content.Intent
import android.media.MediaPlayer
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.OpenableColumns
import android.util.Log
import android.view.View
import android.webkit.MimeTypeMap
import android.widget.Button
import android.widget.ImageView
import android.widget.VideoView
import androidx.core.net.toFile

class MainActivity : AppCompatActivity() {
    val PICTURE=0
    val VIDEO=1
    val AUDIO=2
    var state=PICTURE
    lateinit var mediaPlayer:MediaPlayer
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val browseBtn:Button=findViewById(R.id.browseBtn)
        val videoView:VideoView=findViewById(R.id.videoView)
        browseBtn.setOnClickListener {
            val intent=Intent(Intent.ACTION_OPEN_DOCUMENT)
            intent.addCategory(Intent.CATEGORY_OPENABLE)
            intent.type="*/*"
            if(state==AUDIO){
                mediaPlayer.stop()
                mediaPlayer.release()
            }else if(state==VIDEO){
                videoView.suspend()
            }
            startActivityForResult(intent,1)
        }
        val playBtn:Button=findViewById(R.id.playBtn)
        val pauseBtn:Button=findViewById(R.id.pauseBtn)
        val replayBtn:Button=findViewById(R.id.replayBtn)
        playBtn.setOnClickListener {
            if(state==VIDEO){
                if(!videoView.isPlaying){
                    videoView.start()
                }
            }else if(state==AUDIO){
                mediaPlayer.start()
            }
        }
        pauseBtn.setOnClickListener {
            if(state==VIDEO){
                if(videoView.isPlaying){
                    videoView.pause()
                }else{
                    videoView.start()
                }
            }else if(state==AUDIO){
                if(mediaPlayer.isPlaying){
                    mediaPlayer.pause()
                }else{
                    mediaPlayer.start()
                }
            }
        }
        replayBtn.setOnClickListener {
            if(state==VIDEO){
                videoView.resume()
            }else if(state==AUDIO){
                mediaPlayer.seekTo(0)
                mediaPlayer.start()
            }
        }

    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        Log.d("Main","Result")
        when(requestCode){
            1->{
                if(resultCode==Activity.RESULT_OK&&data!=null){
                    val imageView:ImageView=findViewById(R.id.imageView)
                    val videoView:VideoView=findViewById(R.id.videoView)
                    mediaPlayer=MediaPlayer()
                    data.data?.let { uri ->
                        val filename=uri.pathSegments[1]
                        val lastDot = filename.lastIndexOf(".")
                        val extension=filename.substring(lastDot+1).uppercase();                        Log.d("Main",filename)
                        Log.d("Main",extension)
                        if(extension.contains("IMAGE")||extension=="JPG"){
                            imageView.setImageURI(uri)
                            imageView.visibility=View.VISIBLE
                            videoView.visibility=View.INVISIBLE
                            state=PICTURE
                        }else if(extension=="MP4"){
                            videoView.setVideoURI(uri)
                            videoView.visibility=View.VISIBLE
                            imageView.visibility=View.INVISIBLE
                            state=VIDEO
                        }else if (extension=="MP3"){
                            videoView.visibility=View.INVISIBLE
                            imageView.visibility=View.VISIBLE
                            mediaPlayer.setDataSource(this,uri)
                            mediaPlayer.prepare()
                            state=AUDIO
                        }
                    }

                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if(state==AUDIO){
            mediaPlayer.stop()
            mediaPlayer.release()
        }else if(state==VIDEO){
            val videoView:VideoView=findViewById(R.id.videoView)
            videoView.suspend()
        }
    }


}