package com.example.a3

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.appcompat.app.AlertDialog

class MainActivity2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)
        val from1=intent.getStringExtra("1 to 2")
        AlertDialog.Builder(this).apply {
            setTitle("Data from 1")
            setMessage(from1)
            setCancelable(false)
            setPositiveButton("OK"){dialog,which->}
            setNegativeButton("Cancel"){dialog,which->}
            show()
        }
    }
}