package com.example.a3

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val textView:TextView=findViewById(R.id.textView)
        val buttonTo2:Button=findViewById(R.id.buttonTo2)
        val buttonTo3:Button=findViewById(R.id.buttonTo3)
        buttonTo2.setOnClickListener {
            val intent=Intent(this,MainActivity2::class.java)
            intent.putExtra("1 to 2",textView.text)
            startActivity(intent)
        }
        buttonTo3.setOnClickListener {
            val intent=Intent("MainActivity3")
            startActivityForResult(intent,1)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when(requestCode){
            1-> if(resultCode== RESULT_OK){
                val returnData=data?.getStringExtra("3 to 1")
                Toast.makeText(this,returnData,Toast.LENGTH_SHORT).show()
            }
        }
    }
}