package com.example.a3

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import org.w3c.dom.Text

class MainActivity3 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main3)
        val buttonTo1:Button=findViewById(R.id.buttonTo1)
        buttonTo1.setOnClickListener {
            val intent=Intent(this,MainActivity::class.java)
            val text2:TextView=findViewById(R.id.text2)
            intent.putExtra("3 to 1",text2.text)
            setResult(RESULT_OK,intent)
            finish()
        }
    }
}